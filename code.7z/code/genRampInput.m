function [u] = genRampInput(tVec, timeShift)
    u = tVec - timeShift;
end